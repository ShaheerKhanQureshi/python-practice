a   =
500,b,c;
if (
a >= 400 ): 
b   = 300
c = 200 
print( "Value is:", b, c )   
