#Check whether the number is even or odd
Num= int(input('Enter Any Number'))
if(Num%2==0):
    print(Num,"is even number")
else:
    print(Num,"is odd number")
         