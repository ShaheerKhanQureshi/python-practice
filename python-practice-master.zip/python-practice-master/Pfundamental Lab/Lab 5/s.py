i=1
a=0
while i<11:
    print(i,end=',')
    i +=1
    a=a+i
    
a=a-10
print("\n the sum of first 10 natural number" ,"=", a) 