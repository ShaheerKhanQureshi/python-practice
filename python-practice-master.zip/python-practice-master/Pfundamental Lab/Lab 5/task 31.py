val ='abcd'
for x in range(val):
    print(x)