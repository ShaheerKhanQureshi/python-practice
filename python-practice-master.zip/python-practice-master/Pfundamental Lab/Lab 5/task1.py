i=0
a=0
for i in range(1,11):
    print (i)
    a=a+i
print( " the sum of 10 natural no", a)