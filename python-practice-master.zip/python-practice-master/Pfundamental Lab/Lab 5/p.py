var="vowels"
length = len(var)
i=int(1)
while i != 6:
    if var[i] == "v" or var[i] == "w"  :
        print("none")
        break
    else:
        print("o\ne")
        break
      
 