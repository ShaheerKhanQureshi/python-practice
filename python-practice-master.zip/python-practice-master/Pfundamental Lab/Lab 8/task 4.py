def printsquare():
    a=list()
    for i in range(1,8):
        a.append(i**2)
    print(a)

print("*Following are the squares of the first seven integers stored in a list*")
printsquare()