print("\t ***Names of my Friends***")
names=["Talal Moin","Abdul Moiz Khan","Shaheer Khan Qureshi","Komal Shakeel","Tooba Shakeel","Asma Hashim Khan"]

for i in  names:
    print (i)