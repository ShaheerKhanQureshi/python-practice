food= input('What kind of food would you like : ')
#uppercase command
print('\n Let me see if i can Find you ',food.upper())