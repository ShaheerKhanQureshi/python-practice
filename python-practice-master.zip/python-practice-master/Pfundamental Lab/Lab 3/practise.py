for v in range(3, 9, 2):
    print(v) 