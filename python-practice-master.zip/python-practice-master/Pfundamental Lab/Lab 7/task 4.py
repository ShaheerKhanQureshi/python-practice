def describe_city(city,country):
    print(city,"is in",country)
describe_city("Karachi","Pakistan")
describe_city("Bonn","Germany")
describe_city("Moscow","Russia")