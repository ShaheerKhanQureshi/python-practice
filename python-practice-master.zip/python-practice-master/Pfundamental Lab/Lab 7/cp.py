def type_of_int(i):
    if i // 2 == 0:
        return 'even'
    else:
        return 'odd'
