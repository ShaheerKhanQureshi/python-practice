def favourite_book(title):
    print(title,"is my favourite book")
favourite_book("The Great Gatsby")
favourite_book("Charlie and the chocolate Factory")
favourite_book("The Maze Runner")