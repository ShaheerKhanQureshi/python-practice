#BSE-2020F-022
num1=20
num2=2
mul=num1*num2
print("Multiplication answer=",mul)
div=num1/num2
print("Division Answer=",div)
sub=num1-num2
print("Substraction Answer=",sub)