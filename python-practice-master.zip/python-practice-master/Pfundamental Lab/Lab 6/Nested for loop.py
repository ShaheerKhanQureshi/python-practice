for i in range (1,6):
    print ("\tTable of ",i,"\n")
    for j in range(1,11):
        print(i,"x",j,"=","{:2d}".format(i * j) )
    print("\n")
  