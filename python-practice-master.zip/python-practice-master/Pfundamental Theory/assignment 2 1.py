x="print(55)"
eval(x)