def fav_book(title):
    print(title, "is a very interesting book to read")
    
fav_book("The maze Runner")
fav_book("Charlie and the chocolate factory")
fav_book("Dozakhnama")