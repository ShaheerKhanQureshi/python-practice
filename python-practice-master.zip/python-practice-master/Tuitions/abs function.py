def abse(n):
    print(abs(n))
abse(-1908)
a=b=c=3
print(c)
name="abcdefghij"
print(name[:1])