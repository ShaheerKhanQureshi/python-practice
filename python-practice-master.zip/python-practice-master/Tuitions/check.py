a=["muhammad","taha","azam"]
del a[1]
print(a)