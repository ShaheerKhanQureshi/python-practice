n=input("enter any number")
nn=n*2
nnn=n*3
print(n +"+"+ nn+"+"+nnn +"=",end='')
a= int(n)
aa= int(nn)
aaa=int(nnn)
print (a+aa+aaa)

no= -3.142
print (abs(no))